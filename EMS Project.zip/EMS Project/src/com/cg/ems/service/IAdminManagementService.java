package com.cg.ems.service;

import java.util.ArrayList;

import com.cg.ems.bean.EmployeeBean;

public interface IAdminManagementService {

	
	void addEmployeeDetails(EmployeeBean empBean);

	EmployeeBean getEmployeeDetailsBasedOnId(int empid);

	ArrayList<EmployeeBean> getAllEmployeeDetails();

	
}
