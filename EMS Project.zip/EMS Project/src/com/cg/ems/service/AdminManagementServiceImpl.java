package com.cg.ems.service;

import java.util.ArrayList;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.dao.AdminManagementDAOImpl;
import com.cg.ems.dao.IAdminManagementDAO;

public class AdminManagementServiceImpl implements IAdminManagementService{

	IAdminManagementDAO ied = new AdminManagementDAOImpl();

	@Override
	public void addEmployeeDetails(EmployeeBean empBean) {
		ied.addEmployeeDetails(empBean); 
	}
	@Override
	public EmployeeBean getEmployeeDetailsBasedOnId(int empId) {
		return ied.getEmployeeDetailsBasedOnId(empId);
	}
	@Override
	public ArrayList<EmployeeBean> getAllEmployeeDetails() {
		return ied.getAllEmpoyeeDetails();
	}
	

}
