package com.cg.ems.dao;

import java.util.ArrayList;

import com.cg.ems.bean.EmployeeBean;

public interface IAdminManagementDAO {

	void addEmployeeDetails(EmployeeBean empBean);

	EmployeeBean getEmployeeDetailsBasedOnId(int empId);

	ArrayList<EmployeeBean> getAllEmpoyeeDetails();



	
}
