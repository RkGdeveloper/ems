package com.cg.ems.service;

import java.util.ArrayList;

import com.cg.ems.bean.AddressBean;
import com.cg.ems.bean.DepartmentBean;
import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.dao.AdminManagementDAOImpl;
import com.cg.ems.dao.IAdminManagementDAO;

public class AdminManagementServiceImpl implements IAdminManagementService{

	IAdminManagementDAO ied = new AdminManagementDAOImpl();

	@Override
	public void addEmployeeDetails(EmployeeBean empBean) {
		ied.addEmployeeDetails(empBean); 
	}
	@Override
	public EmployeeBean getEmployeeDetailsBasedOnId(int empId) {
		return ied.getEmployeeDetailsBasedOnId(empId);
	}
	@Override
	public ArrayList<EmployeeBean> getAllEmployeeDetails() {
		return ied.getAllEmpoyeeDetails();
	}
	
	
	
	
	@Override
	public int updateFirstName(String fName, int empId) {
		return ied.updateFirstName(fName,empId);
	}
	@Override
	public int updateLastName(String lName, int empId) {
		return ied.updateLastName(lName,empId);
	}
	@Override
	public int updateDepartmentName(String dName, int deptId) {
		return ied.updateDepartmentName(dName,deptId);
	}
	@Override
	public int updateDesignationName(String desigName, int empId) {
		return ied.updateDesignationName(desigName,empId);
	}
	@Override
	public int updateSalary(String salary, int empId) {
		return ied.updateSalary(salary, empId);
	}
	@Override
	public int updateMaritalStatus(String marital, int empId) {
		return ied.updateMaritalStatus(marital,empId);
	}
	@Override
	public int updateHomeAddr(AddressBean addr, int empId) {
		return ied.updateHomeAddr(addr,empId);
	}
	@Override
	public int updateContactNumber(String contactNum, int empId) {
		return ied.updateContactNumber(contactNum, empId);
	}
	@Override
	public DepartmentBean getDepartmentDetailsById(int deptId) {
		return ied.getDepartmentDetails(deptId);
	}
	
	


}
