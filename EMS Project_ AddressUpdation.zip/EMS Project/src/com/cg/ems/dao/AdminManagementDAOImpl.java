package com.cg.ems.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.ems.bean.AddressBean;
import com.cg.ems.bean.DepartmentBean;
import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.dbconfig.DbUtil;

public class AdminManagementDAOImpl implements IAdminManagementDAO{


	@Override
	public void addEmployeeDetails(EmployeeBean empBean) {
		try {
			System.out.println(empBean);
			Connection con = DbUtil.getConnection();
			PreparedStatement pst = con.prepareStatement("INSERT INTO Employee_table VALUES(emp_table_seq.nextval,?,?,?,?,?,?,?,?,?,?,?,?)");
			pst.setString(1, empBean.getFirstName());
			pst.setString(2, empBean.getLastName());
			pst.setDate(3, empBean.getDateOfJoining());
			pst.setDate(4, empBean.getDateOfBirth());
			pst.setInt(5, empBean.getDeptId());
			pst.setInt(6, empBean.getDesignationId());
			pst.setString(7, empBean.getGrade());
			pst.setString(8, empBean.getGender());
			pst.setLong(9,empBean.getSalary());
			pst.setString(10, empBean.getMartialStatus());
			pst.setInt(11, empBean.getAddressId());
			pst.setLong(12, empBean.getContactNo());
			
			int noOfRows = pst.executeUpdate();
			if(noOfRows > 0)
				System.out.println("Row inserted ");
			else
				System.out.println("Failed");
			
		} catch (IOException | SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public EmployeeBean getEmployeeDetailsBasedOnId(int empId) {
		
		EmployeeBean empB = new EmployeeBean();
		try {
			Connection con = DbUtil.getConnection();
			PreparedStatement pst = con.prepareStatement("select * from Employee_table where Emp_Id = ?");
				pst.setInt(1, empId);
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()){
				empB.setEmpId(rs.getInt(1));
				empB.setFirstName(rs.getString(2));
				empB.setLastName(rs.getString(3));
				empB.setDateOfJoining(rs.getDate(4));
				empB.setDateOfBirth(rs.getDate(5));
				empB.setDeptId(rs.getInt(6));
				empB.setDesignationId(rs.getInt(7));
				empB.setGrade(rs.getString(8));
				empB.setGender(rs.getString(9));
				empB.setSalary(rs.getLong(10));
				empB.setMartialStatus(rs.getString(11));
				empB.setAddressId(rs.getInt(12));
				empB.setContactNo(rs.getLong(13));
			}
			System.out.println(empB);
			//System.out.println("Result is "+rs);
		} catch (IOException | SQLException e) {
			e.printStackTrace();
		}
		return empB;
	}

	
	@Override
	public ArrayList<EmployeeBean> getAllEmpoyeeDetails() {
		ArrayList<EmployeeBean> empBeanList = new ArrayList<EmployeeBean>();
		EmployeeBean empB =null;
		try {
			Connection con = DbUtil.getConnection();
			String query = "select * from Employee_table";
			Statement st = con.createStatement();

			
 			ResultSet rs = st.executeQuery(query);
			
			while(rs.next()){
				empB = new EmployeeBean();
				
				empB.setEmpId(rs.getInt(1));
				empB.setFirstName(rs.getString(2));
				empB.setLastName(rs.getString(3));
				empB.setDateOfJoining(rs.getDate(4));
				empB.setDateOfBirth(rs.getDate(5));
				empB.setDeptId(rs.getInt(6));
				empB.setDesignationId(rs.getInt(7));
				empB.setGrade(rs.getString(8));
				empB.setGender(rs.getString(9));
				empB.setSalary(rs.getLong(10));
				empB.setMartialStatus(rs.getString(11));
				empB.setAddressId(rs.getInt(12));
				empB.setContactNo(rs.getLong(13));
				//System.out.println(empB);
				empBeanList.add(empB);
			}
		} catch (IOException | SQLException e) {
			e.printStackTrace();
		}
		return empBeanList;
	}

	
	
	/**************************** Update Methods ********************************/
	@Override
	public int updateFirstName(String fName, int empId) {
		int result = 0;
		try {
			Connection con = DbUtil.getConnection();
			
			String updateQ = "UPDATE Employee_table SET emp_firstName = ? WHERE Emp_id = ?";
			PreparedStatement pst = con.prepareStatement(updateQ);
			pst.setString(1, fName);
			pst.setInt(2, empId);
			result = pst.executeUpdate();
		
		} catch (IOException | SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public int updateLastName(String lName, int empId) {
		int result = 0;
		try {
			Connection con = DbUtil.getConnection();
			
			String updateQ = "UPDATE Employee_table SET emp_lastName = ? WHERE Emp_id = ?";
			PreparedStatement pst = con.prepareStatement(updateQ);
			pst.setString(1, lName);
			pst.setInt(2, empId);
			result = pst.executeUpdate();
		
		} catch (IOException | SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public int updateDepartmentName(String dName, int deptId) {
		int result = 0;
		try {
			Connection con = DbUtil.getConnection();
			
			String updateQ = "UPDATE Department_table SET department_name = ? WHERE department_id = ?";
			PreparedStatement pst = con.prepareStatement(updateQ);
			pst.setString(1, dName);
			pst.setInt(2, deptId);
			result = pst.executeUpdate();
		
		} catch (IOException | SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public int updateDesignationName(String desigName, int desigId) {
		
		int result = 0;
		try {
			Connection con = DbUtil.getConnection();
			
			String updateQ = "UPDATE Designation_table SET designation_name = ? WHERE designation_id = ?";
			PreparedStatement pst = con.prepareStatement(updateQ);
			pst.setString(1, desigName);
			pst.setInt(2, desigId);
			
			result = pst.executeUpdate();
		
		} catch (IOException | SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public int updateSalary(String salary, int empId) {
		int result = 0;
		try {
			Connection con = DbUtil.getConnection();
			
			String updateQ = "UPDATE Employee_table SET emp_Salary = ? WHERE Emp_id = ?";
			PreparedStatement pst = con.prepareStatement(updateQ);
			pst.setString(1, salary);
			pst.setInt(2, empId);
			result = pst.executeUpdate();
		
		} catch (IOException | SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public int updateMaritalStatus(String marital, int empId) {
		int result = 0;
		try {
			Connection con = DbUtil.getConnection();
			
			String updateQ = "UPDATE Employee_table SET emp_marital_status = ? WHERE Emp_id = ?";
			PreparedStatement pst = con.prepareStatement(updateQ);
			pst.setString(1, marital);
			pst.setInt(2, empId);
			result = pst.executeUpdate();
		
		} catch (IOException | SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public int updateHomeAddr(AddressBean addr, int addressId) {
		int result = 0;
		try {
		System.out.println("in dao "+addr);
		System.out.println("in dao "+addressId);
			
			Connection con = DbUtil.getConnection();
			
			String updateQ = "UPDATE Address_table SET door_number=?,street=?,landmark=?,area=?,pincode=?,district=?,state=? WHERE Address_id=?";
			PreparedStatement pst = con.prepareStatement(updateQ);
			pst.setInt(1, addr.getDoorNo());
			pst.setString(2, addr.getStreet());
			pst.setString(3, addr.getLandmark());
			pst.setString(4, addr.getArea());
			pst.setInt(5,addr.getPincode());
			pst.setString(6, addr.getDistrict());
			pst.setString(7, addr.getState());
			pst.setInt(8, addressId);
			result = pst.executeUpdate();
			
			
		System.out.println("from dao "+result);
		
			
		} catch (IOException | SQLException e) {
			e.printStackTrace();
		}
		return result;
		
	}

	@Override
	public int updateContactNumber(String contactNum, int empId) {
		int result = 0;
		try {
			Connection con = DbUtil.getConnection();
			
			String updateQ = "UPDATE Employee_table SET emp_contact = ? WHERE Emp_id = ?";
			PreparedStatement pst = con.prepareStatement(updateQ);
			pst.setString(1, contactNum);
			pst.setInt(2, empId);
			result = pst.executeUpdate();
		
		} catch (IOException | SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public DepartmentBean getDepartmentDetails(int deptId) {
	
		DepartmentBean deptB = new DepartmentBean();
		
			Connection con;
			try {
				con = DbUtil.getConnection();
				String query = "select * from department_table where Department_id = ?";
				PreparedStatement st = con.prepareStatement(query);
				st.setInt(1, deptId);
	 			ResultSet rs = st.executeQuery();
				
				while(rs.next()){
					deptB.setDeptId(rs.getInt(1));
					deptB.setDeptName(rs.getString(2));
				}
			System.out.println("In dao Layer"+deptB);
				
			} catch (IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
		
		return deptB;
	}

	
	
}
