package com.cg.ems.dao;

import java.util.ArrayList;

import com.cg.ems.bean.DepartmentBean;
import com.cg.ems.bean.EmployeeBean;

public interface IAdminManagementDAO {

	void addEmployeeDetails(EmployeeBean empBean);

	EmployeeBean getEmployeeDetailsBasedOnId(int empId);

	ArrayList<EmployeeBean> getAllEmpoyeeDetails();

	int updateFirstName(String fName, int empId);

	int updateLastName(String lName, int empId);

	int updateDepartmentName(String dName, int deptId);

	int updateDesignationName(String desigName, int empId);

	int updateSalary(String salary, int empId);

	int updateMaritalStatus(String marital, int empId);

	int updateHomeAddr(String addr, int empId);

	int updateContactNumber(String contactNum, int empId);

	DepartmentBean getDepartmentDetails(int deptId);



	
}
